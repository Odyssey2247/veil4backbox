<?php
/**
 * @package   T3 Blank
 * @copyright Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
?>
<!-- copyright -->
<div id="copyright">
	<div class="container">
		<p>&copy; Copyright <?php echo date('Y'); ?> <?php $config = JFactory::getConfig(); echo $config['sitename']; ?><a href="https://www.joomdev.com/products/templates" target="_blank"> <strong>Joomla Templates</strong></a> by <a href="http://www.joomdev.com" target="_blank"><strong>JoomDev</strong></a></p>
	</div>
</div>
<!-- //copyright -->